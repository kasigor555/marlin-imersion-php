<?php
/**
 * Константы подключение к базе
 */
define('SERVERNAME', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DBNAME', 'product_catalog');