<?php



?>

<footer class="footer mt-auto py-3">
  <div class="container">
    <span class="text-muted">&copy; 2017 - <?php echo date('Y'); ?></span>
  </div>
</footer>

</body>

</html>